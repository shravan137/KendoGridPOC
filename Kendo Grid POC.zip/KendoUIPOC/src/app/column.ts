export interface IColumn {
    field: string;
    title: string;
    format?: string;
    required: boolean;
    type: 'text' | 'numeric' | 'boolean' | 'date' | 'dropdown';
    isReadOnly: boolean;
}