import { Component } from '@angular/core';
import { gridJSONData, categoryData } from './gridData';
import { products } from './products';
import { IColumn } from './column';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  public gridData: any;
  public dropdownData = categoryData;
  public columns: IColumn[] = [
    {
      field: 'ProductName',
      title: 'Product Name',
      type: 'text',
      required: true,
      isReadOnly: false
    },
    {
      field: 'CategoryID',
      title: 'Category',
      type: 'dropdown',
      required: false,
      isReadOnly: false
    }, {
      field: 'UnitPrice',
      format: '{0:c}',
      title: 'Unit Price',
      type: 'numeric',
      required: true,
      isReadOnly: false
    }, {
      field: 'UnitsInStock',
      title: 'Units In Stock',
      type: 'numeric',
      required: true,
      isReadOnly: false
    }
  ];

  public childColumns: IColumn[] = [
    {
      field: 'id',
      title: 'ID',
      type: 'numeric',
      required: true,
      isReadOnly: true
    },
    {
      field: 'name',
      title: 'Name',
      type: 'text',
      required: true,
      isReadOnly: false
    }
  ];
  constructor() {

    this.gridData = products;
    //alert(this.gridData);
  }

  gridDataSave(event: Event) {
    alert(event);
  }
}
