export const gridJSONData = [{
  'ProductID': 1,
  'ProductName': 'Chai',
  'SupplierID': 1,
  'CategoryID': 1,
  'CategoryName': 'Beverages',
  'QuantityPerUnit': '10 boxes x 20 bags',
  'UnitPrice': 18.0000,
  'UnitsInStock': 39,
  'UnitsOnOrder': 0,
  'ReorderLevel': 10,
  'Discontinued': false,
  children: [{
    id: 1,
    name: 'foo-child-1',
    children: [{
      id: 1,
      name: 'foo-child-1'
    }, {
      id: 2,
      name: 'foo-child-2'
    }]
  }, {
    id: 2,
    name: 'foo-child-2',
    children: [{
      id: 1,
      name: 'foo-child-1'
    }, {
      id: 2,
      name: 'foo-child-2'
    }]
  }]
}, {
  'ProductID': 2,
  'ProductName': 'Chang',
  'SupplierID': 1,
  'CategoryID': 1,
  'CategoryName': 'Beverages',
  'QuantityPerUnit': '24 - 12 oz bottles',
  'UnitPrice': 19.0000,
  'UnitsInStock': 17,
  'UnitsOnOrder': 40,
  'ReorderLevel': 25,
  'Discontinued': false,
  children: [{
    id: 3,
    name: 'bar-child-1',
    children: [{
      id: 3,
      name: 'bar-child-1'
    }, {
      id: 4,
      name: 'bar-child-2'
    }]
  }, {
    id: 4,
    name: 'bar-child-2',
    children: [{
      id: 3,
      name: 'bar-child-1'
    }]
  }, {
    id: 5,
    name: 'bar-child-3',
    children: [{
      id: 3,
      name: 'bar-child-1'
    }]
  }]
}, {
  'ProductID': 3,
  'ProductName': 'Aniseed Syrup',
  'SupplierID': 1,
  'CategoryID': 2,
  'CategoryName': 'Condiments',
  'QuantityPerUnit': '12 - 550 ml bottles',
  'UnitPrice': 10.0000,
  'UnitsInStock': 13,
  'UnitsOnOrder': 70,
  'ReorderLevel': 25,
  'Discontinued': false,
  children: [{
    id: 3,
    name: 'bar-child-1',
    children: [{
      id: 3,
      name: 'bar-child-1'
    }]
  }, {
    id: 4,
    name: 'bar-child-2',
    children: [{
      id: 3,
      name: 'bar-child-1'
    }]
  }, {
    id: 5,
    name: 'bar-child-3'
  }]
},];

export const categoryData = [
  {
    'CategoryID': 1,
    'CategoryName': 'Beverages',
    'Description': 'Soft drinks, coffees, teas, beers, and ales'
  },
  {
    'CategoryID': 2,
    'CategoryName': 'Condiments',
    'Description': 'Sweet and savory sauces, relishes, spreads, and seasonings'
  },
  {
    'CategoryID': 3,
    'CategoryName': 'Confections',
    'Description': 'Desserts, candies, and sweet breads'
  },
  {
    'CategoryID': 4,
    'CategoryName': 'Dairy Products',
    'Description': 'Cheeses'
  },
  {
    'CategoryID': 5,
    'CategoryName': 'Grains/Cereals',
    'Description': 'Breads, crackers, pasta, and cereal'
  },
  {
    'CategoryID': 6,
    'CategoryName': 'Meat/Poultry',
    'Description': 'Prepared meats'
  },
  {
    'CategoryID': 7,
    'CategoryName': 'Produce',
    'Description': 'Dried fruit and bean curd'
  },
  {
    'CategoryID': 8,
    'CategoryName': 'Seafood',
    'Description': 'Seaweed and fish'
  }
];